# 2D Knights Platformer
## Original Creators Video Tutorial
[Brackeys First Game Tutorial (Platformer)](https://youtu.be/LOhfqjmasi0?feature=shared)
## Try the game
[2D Knights Platformer (Brackeys)](https://jvansant13.github.io/Technology-Specials/2d%20Knights%20Platformer/Game/)
## Lessons
1. [Player 1.0]()
2. [Worldbuilding 1.0]()
3. [Platforms]()
4. [Pickups]()
5. [Dying]()
6. [Worldbuilding 2.0]()
7. [Enemy]()
8. [Dying 2.0]()
9. [Player 2.0]()
10. [Text, Score, Audio]()
11. [Export]()
